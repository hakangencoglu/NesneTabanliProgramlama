public class Binek extends Otomobil{

    @Override
    public void metot1(){
        super.metot1();
        System.out.println("Metot1                 çalıştı");
    }

}


