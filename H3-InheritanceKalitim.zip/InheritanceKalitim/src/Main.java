public class Main {
    public static void main(String[] args) {
        //Kısım 2
        Otomobil o2 = new Otomobil("Audi","A1");
        //o2.metot();

        System.out.println("******************************************");
        Ticari ticari1 = new Ticari();
        //ticari1.metot();

        System.out.println("******************************************");
        Binek binek1 = new Binek();
        //binek1.metot();



        //Kısım 1
        /*
        Otomobil o1 = new Otomobil();
        o1.OtomobilMetotu("Fiat","Egea");
        System.out.println("******************************************");
        Binek b1 = new Binek();
        b1.OtomobilMetotu("Opel","Insignia");
        b1.BinekMetotu("Mercedes","C200");


        System.out.println("******************************************");
        MiniBinek mb1 = new MiniBinek();
        mb1.OtomobilMetotu("Toyota","Corolla");
        mb1.BinekMetotu("Mercedes","A180");
        mb1.MiniBinekMetotu("Fiat","Palio");

        System.out.println("******************************************");
        Ticari to1 = new Ticari();
        to1.TicariOtomobilMetotu("Fiat","Fiorino");
        */


    }
}
