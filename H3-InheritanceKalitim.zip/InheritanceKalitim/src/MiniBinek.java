public class MiniBinek extends Binek{
    public void MiniBinekMetotu(String Marka, String Model){
        System.out.println("Mini Binek: "+ Marka+ " " +Model);
    }
}
