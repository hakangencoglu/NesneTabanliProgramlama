public class TicariBinek {
}
