public class Ogrenci {
    String ad;
    String soyad;
    int yas;
    String dogumYeri;
}
