public class Ucgen extends CokGen{
    Ucgen(int kenarSayisi, int kenarUzunlugu) {
        super(kenarSayisi, kenarUzunlugu);
    }

    int ucgeninAlani(){

        return 3;
    }
}
