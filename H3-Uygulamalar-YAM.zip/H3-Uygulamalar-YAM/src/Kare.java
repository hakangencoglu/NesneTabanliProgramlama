public class Kare {
}
