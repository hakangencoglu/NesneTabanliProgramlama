public class Ogrenci {

    String isim,soyisim;
    int id;

    public void goruntule(){
        System.out.println(id);
    }

}
