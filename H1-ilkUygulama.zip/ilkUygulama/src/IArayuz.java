public interface IArayuz {
}
