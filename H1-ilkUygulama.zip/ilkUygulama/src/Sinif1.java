public class Sinif1 {
}
