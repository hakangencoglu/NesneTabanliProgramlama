public class Nokta {

}
